from sl07_actor import Arena, Actor
import random
import g2d


class Buche(Actor):
    def __init__(self, arena, x=500):
        self._x = x
        self._y = 399
        self._w1, self._h1 = 20, 20
        self._w2, self._h2 = 30, 40
        self._velocità = -3
        self._arena = arena
        arena.add(self)
        self._dx = self._velocità
        self._dy = 0
        self._bool = bool(random.getrandbits(1))

    def move(self):
        self._x += self._dx
        if self._bool:
            if self._x <= 0 - self._w1:
                self._arena.remove(self)
        else:
            if self._x <= 0 - self._w2:
                self._arena.remove(self)

    def symbol(self):
        if self._bool:
            return 136, 139, 15, 13
        else:
            return 158, 166, 183 - 158, 195 - 166

    def position(self):
        if self._bool:
            return self._x, self._y, self._w1, self._h1
        else:
            return self._x, self._y, self._w2, self._h2

    def collide(self, other):
        if isinstance(other, Rover):
            esplosione = Esplosione(self._arena, other)
            self._arena.remove(other)
            self._arena.stay_all()
            self._arena.stop()

    def stay(self):
        self._dx = 0


class Rover(Actor):

    def __init__(self, arena, x, y):
        self._x, self._y = x, y
        self._w, self._h = 35, 30
        self._speed = 8
        self._dx, self._dy = 0, 0
        self._arena = arena
        self._arena_w, self._arena_h = self._arena.size()
        self._g = 0.4

        arena.add(self)

    def move(self):
        arena_w, arena_h = self._arena.size()
        self._y += self._dy
        self._dy += self._g
        self._x += 0

        if self._y >= self._arena_h - self._h - 98:
            self._y = arena_h - self._h - 98
            self._dy = 0

        if self._x < 0 + self._w - 30:
            self._x = 0 + self._w - 30
        elif self._x > self._arena_w - self._w:
            self._x = self._arena_w - self._w

        if self._y == self._arena_h - self._h - 98:
            if g2d.key_pressed("ArrowUp"):
                Rover.go_up(self)

        if g2d.key_released("ArrowUp"):
            Rover.stay(self)

        if g2d.key_pressed('Spacebar'):
            Bullet(self._arena, self._x + 1 / 4 * self._w, self._y, 0, -5)
            Bullet(self._arena, self._x + self._w, self._y + 1 / 2 * self._h, 5, 0)

    def go_left(self):
        self._dx, self._dy = -self._speed, 0

    def go_right(self):
        self._dx, self._dy = +self._speed, 0

    def go_up(self):
        self._dx, self._dy = 0, -self._speed

    def go_down(self):
        self._dx, self._dy = 0, +self._speed

    def stay(self):
        self._dx, self._dy = 0, 0

    def collide(self, other):
        if isinstance(other, Bullet):
            Esplosione(self._arena, self)
            self._arena.remove(self)
            self._arena.stay_all()
            self._arena.stop()

    def position(self):
        return self._x, self._y, self._w, self._h

    def symbol(self):
        if self._dy > 0:
            return 79, 103, 30, 28
        if self._dy < 0:
            return 46, 102, 29, 28
        if self._dy == 0:
            return 211, 157, 32, 24


class Sfondi(Actor):

    def __init__(self, arena, pos: (int, int, int, int), imag: (int, int, int, int), velocità):
        self._x, self._y, self._w, self._h = pos
        self._imagx, self._imagy, self._imagw, self._imagh = imag
        self._velocità = velocità
        self._arena = arena
        self._initx = self._x
        arena.add(self)
        self._dx = velocità
        self._dy = 0

    def move(self):
        self._x += self._dx
        if self._initx - self._x >= 500:
            self._x = self._initx

    def symbol(self):
        return self._imagx, self._imagy, self._imagw, self._imagh

    def position(self):
        return self._x, self._y, self._w, self._h

    def collide(self, other):
        pass

    def stay(self):
        self._dx = 0


class Rocce(Actor):

    def __init__(self, arena, y, choice):

        self._w1, self._h1 = 20, 20
        self._w2, self._h2 = 30, 40
        self._x = 500
        self._y = y
        self._velocità = -3
        self._arena = arena
        arena.add(self)
        self._dx = self._velocità
        self._dy = 0
        self._bool = choice
        self._life = 1

    def move(self):
        self._x += self._dx
        if self._bool:
            if self._x <= 0 - self._w1:
                self._arena.remove(self)
        else:
            if self._x <= 0 - self._w2:
                self._arena.remove(self)

    def symbol(self):
        if self._bool:
            return 62, 208, 10, 10
        else:
            return 94, 200, 16, 18

    def position(self):
        if self._bool:
            return self._x, self._y, self._w1, self._h1
        else:
            return self._x, self._y, self._w2, self._h2

    def collide(self, other):
        if isinstance(other, Rover):
            esplosione = Esplosione(self._arena, other)
            self._arena.remove(other)
            self._arena.stay_all()
            self._arena.stop()
        if isinstance(other, Bullet):
            Esplosione(self._arena, other)
            if not self._bool:
                if self._life == 0:
                    self._arena.remove(self)
                else:
                    self._life -= 1
            else:
                self._arena.remove(self)
            self._arena.remove(other)

    def stay(self):
        self._dx = 0


class Esplosione(Actor):
    def __init__(self, arena, oggetto):
        self._oggetto = oggetto
        self._x, self._y, self._w, self._h = self._oggetto.position()
        self._time = 0
        if isinstance(oggetto, Rover):
            self._dx = 0
        else:
            self._dx = -3
        self._arena = arena
        self._arena.add(self)

    def move(self):

        self._x += self._dx

        if self._time >= 30:
            self._arena.remove(self)

    def symbol(self) -> (int, int, int, int):
        if isinstance(self._oggetto, Rover):
            self._time += 1
            return 213, 102, 42, 29
        else:
            self._time += 1
            return 238, 139, 9, 11

    def collide(self, other):
        pass

    def position(self):
        if isinstance(self._oggetto, Bullet):
            return self._x, self._y-10, 20, 20
        return self._x, self._y, self._w, self._h

    def stay(self):
        self._dx = 0


class Bullet(Actor):
    def __init__(self, arena, x, y, dx, dy):
        self._x = x
        self._y = y
        self._dx = dx
        self._dy = dy
        self._arena = arena
        self._arena.add(self)

    def move(self):
        w, h = self._arena.size()
        if self._x >= w + 5 or self._y <= 0 - 5:
            self._arena.remove(self)
        self._x += self._dx
        self._y += self._dy
        if self._y > 400:
            self._arena.remove(self)
            ran = random.randint(1, 10)
            if ran == 5:
                Buche(self._arena, self._x)

    def symbol(self):
        return 0, 0, 0, 0

    def collide(self, other):
        if isinstance(other, Bullet):
            Esplosione(self._arena, other)
            self._arena.remove(self)

    def stay(self):
        self._dx, self._dy = 0, 0

    def position(self):
        return self._x, self._y, 5, 5


class Alien(Actor):
    def __init__(self, arena, x, y, dx):
        self._x = x
        self._y = y
        self._dx = dx
        self._r = 20
        self._s = 20
        self._arena = arena
        self._arena.add(self)
        
    def move(self):
        self._x += self._dx

        rand = random.randint(1, 10)
        if not self._arena.getstop():

            if rand == 1:
                self._dx = random.choice([-5, 0, 5])

            rand2 = random.randint(1, 60)
            if rand2 == 4:
                Bullet(self._arena, self._x, self._y + self._r, 0, 3)


        if self._x > 500 - self._r:
            self._dx = 0
            self._x = 500 - self._r

        if self._x < 0 + self._s:
            self._dx = 0
            self._x = 0 + self._s

    def symbol(self):
        return 121, 227, 17, 10

    def collide(self, other: 'Actor'):
        if isinstance(other, Bullet):
            Esplosione(self._arena, other)
            self._arena.remove(self)

    def stay(self):
        self._dx, self._dy = 0, 0

    def position(self):
        return self._x, self._y, self._r, self._s
