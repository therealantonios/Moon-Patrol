import g2d
from sl07_actor import Arena, Actor
from classi import Buche, Rover, Sfondi, Rocce, Alien
import random

bucacont = 0
roccecont = 0

def update():
    global bucacont, roccecont
    g2d.clear_canvas()
    arena.move_all()
    g2d.draw_image_clip(sfondi, (0, 0, 512, 218), (0, 0, 500, 500))  # cielo fermo

    if random.randint(0, 50) == 0 and bucacont >= 30 and arena.getstop() is False and roccecont >= 30:
        buca = Buche(arena)
        bucacont = 0

    if random.randint(0, 50) == 0 and roccecont >= 30 and arena.getstop() is False and bucacont >= 30:
        choice = bool(random.getrandbits(1))
        if choice:
            roccia= Rocce(arena, 400 - 10, choice)
        else:
            roccia = Rocce(arena, 400- 30, choice)
        roccecont = 0

    for a in arena.actors():
        if a.symbol() != (0, 0, 0, 0):
            if isinstance(a, Sfondi):
                g2d.draw_image_clip(sfondi, a.symbol(), a.position())
            else:
                g2d.draw_image_clip(sprites, a.symbol(), a.position())
        else:
            g2d.fill_rect(a.position())
    bucacont += 1
    roccecont += 1

arena_w = 500
arena_h = 500
sprites = g2d.load_image("moon_patrol.png")
sfondi = g2d.load_image("moon_patrol_bg.png")
arena = Arena(500, 500)

g1 = Sfondi(arena, (0, 230, 500, 270), (0, 258, 512, 130), -1)  # sfondo collina1
g2 = Sfondi(arena, (500, 230, 500, 270), (0, 258, 512, 130), -1)  # sfondo collina2
s1 = Sfondi(arena, (0, 400, 500, 100), (0, 513, 512, 125), -3)  # sfondo terra1
s2 = Sfondi(arena, (500, 400, 500, 100), (0, 513, 512, 125), -3)  # sfondo terra2
r = Rover(arena, 90, 410)  #rover
a1 = Alien(arena,250, 250, 3)  #alieno1
a2 = Alien(arena,250, 250, 3)  #alieno2

def main():
    g2d.init_canvas((500, 500))
    g2d.main_loop(update)

if __name__ == '__main__':
    main()
