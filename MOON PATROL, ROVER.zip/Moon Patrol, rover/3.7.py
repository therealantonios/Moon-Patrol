import g2d
from sl07_actor import Arena, Actor
from classi import Sfondi


class Rover(Actor):

    def __init__(self, arena, x, y):
        self._x, self._y = x, y
        self._w, self._h = 35, 30
        self._speed = 8
        self._dx, self._dy = 0, 0
        self._arena = arena
        self._arena_w, self._arena_h = self._arena.size()
        self._g = 0.4

        arena.add(self)

    def move(self):
        self._y += self._dy
        self._dy += self._g
        self._x += 0

        if self._y >= self._arena_h - self._h - 98:
            self._y = arena_h - self._h - 98
            self._dy = 0

        if self._x < 0 + self._w - 30:
            self._x = 0 + self._w - 30
        elif self._x > self._arena_w - self._w:
            self._x = self._arena_w - self._w

        if self._y == self._arena_h - self._h - 98:
            if g2d.key_pressed("ArrowUp"):
                Rover.go_up(self)

        if g2d.key_released("ArrowUp"):
            Rover.stay(self)

    def go_left(self):
        self._dx, self._dy = -self._speed, 0

    def go_right(self):
        self._dx, self._dy = +self._speed, 0

    def go_up(self):
        self._dx, self._dy = 0, -self._speed

    def go_down(self):
        self._dx, self._dy = 0, +self._speed

    def stay(self):
        self._dx, self._dy = 0, 0

    def collide(self, other):
        pass

    def position(self):
        return self._x, self._y, self._w, self._h

    def symbol(self):
        if self._dy > 0:
            return 79, 103, 30, 28
        if self._dy < 0:
            return 46, 102, 29, 28
        if self._dy == 0:
            return 211, 157, 32, 24




def update():
    g2d.clear_canvas()
    arena.move_all()
    g2d.draw_image_clip(sfondi, (0, 0, 512, 218), (0, 0, 500, 500))  # cielo fermo

    for a in arena.actors():
        if a.symbol() != (0, 0, 0, 0):
            if isinstance(a, Sfondi):
                g2d.draw_image_clip(sfondi, a.symbol(), a.position())
            else:
                g2d.draw_image_clip(sprites, a.symbol(), a.position())
        else:
            g2d.fill_rect(a.position())



arena_w = 500
arena_h = 500
sprites = g2d.load_image("moon_patrol.png")
sfondi = g2d.load_image("moon_patrol_bg.png")
arena = Arena(500, 500)

g = Sfondi(arena, (0, 230, 500, 270), (0, 258, 512, 130), -1)  # sfondo collina
g2 = Sfondi(arena, (500, 230, 500, 270), (0, 258, 512, 130), -1)  # sfondo collina2
s = Sfondi(arena, (0, 400, 500, 100), (0, 513, 512, 125), -3)  # sfondo terra
s2 = Sfondi(arena, (500, 400, 500, 100), (0, 513, 512, 125), -3)  # sfondo terra2
r = Rover(arena, 90, 410)





def main():
    g2d.init_canvas((500, 500))
    g2d.main_loop(update)


if __name__ == '__main__':
    main()
