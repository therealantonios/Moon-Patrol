import g2d
arena_w = 500
arena_h = 500
class Rover:

    def __init__(self, arena, x, y):
        self._x, self._y = x, y
        self._w, self._h = 20, 50
        self._speed = 8
        self._dx, self._dy = 0, 0
        self._arena_w = arena_w
        self._arena_h = arena_h
        self._g = 0.4

    def move(self):
        self._y += self._dy
        self._dy += self._g
        self._x += self._dx

        if self._y >= arena_h - self._h:
            self._y = arena_h - self._h
            self._dy = 0

        if self._x < 0 + self._w:
            self._x = 0 + self._w
        elif self._x > arena_w - self._w:
            self._x = arena_w - self._w

        if self._y== arena_h - self._h:
            if g2d.key_pressed("ArrowUp"):
                Rover.go_up(self)

            
        if g2d.key_pressed("ArrowLeft"):
            Rover.go_left(self)
        elif g2d.key_pressed("ArrowRight"):
            Rover.go_right(self)
        elif (g2d.key_released("ArrowUp") or
                g2d.key_released("ArrowLeft") or
                g2d.key_released("ArrowRight")):
            Rover.stay(self)

    def go_left(self):
        self._dx, self._dy = -self._speed, 0
        
    def go_right(self):
        self._dx, self._dy = +self._speed, 0

    def go_up(self):
        self._dx, self._dy = 0, -self._speed
        
    def go_down(self):
        self._dx, self._dy = 0, +self._speed

    def stay(self):
        self._dx, self._dy = 0, 0

    def collide(self, other):
        pass
        
    def position(self):
        return self._x, self._y, self._w, self._h

    def symbol(self):
        return 0, 20, self._w, self._h
    def val(self):
        return(self._x, self._y)
def update():
    global Rover
    g2d.clear_canvas()
    g2d.fill_circle((r.val()), 20)
    r.move()
g2d.init_canvas((500,500))
r = Rover(500,20,20)
g2d.main_loop(update)
    
    
